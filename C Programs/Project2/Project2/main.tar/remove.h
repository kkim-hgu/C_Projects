#define FALSE 0
#define TRUE 1

//void remove_class locates and removes the first class containing the user-specified string
//int *department_count the integer representation of the array size
//class_info_t *class_array[] the array being investigated
//char *class_count the string representation of the array size
void remove_class(int *department_count, class_info_t *class_array[], char *class_count);
