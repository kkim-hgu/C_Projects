//void add adds new user-requested data to the array
//int *department_count the size of the array bieng used
//class_info_t *class_array[] the array the content is being added to
//char *class_count the string representing the size of the class_array
void add(int *department_count, class_info_t *class_array[], char *class_count);
